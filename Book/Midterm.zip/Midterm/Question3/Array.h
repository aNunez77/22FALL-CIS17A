/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Array.h
 * Author: antho
 *
 * Created on October 24, 2022, 12:48 PM
 */

#ifndef ARRAY_H
#define ARRAY_H

struct Array{
    int size; //Size of the Array
    int *data;//Values contained in the array
};

#endif /* ARRAY_H */