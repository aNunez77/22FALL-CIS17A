

/* 
 * File:   Question5.cpp
 * Author: Anthony Nunez
 *
 * Created on October 24, 2022, 11:01 PM
 */

#include <cstdlib>

using namespace std;

int main(int argc, char** argv) {

    cout << "largest factorial for char is 1\n";
    cout << "largest factorial for unsigned char is 1\n";
    cout << "largest factorial for short is 7\n";
    cout << "largest factorial for unsigned short is 17\n";
    cout << "largest factorial for int is 16\n";
    cout << "largest factorial for unsigned int is 33\n";
    cout << "largest factorial for long is 20\n";
    cout << "largest factorial for unsigned long is 65\n";
    cout << "largest factorial for long long is 20\n";
    cout << "largest factorial for unsigned long long is 65 \n";
    cout << "largest factorial for float is 34.00\n";
    cout << "largest factorial for double is 170.00\n";
    cout << "largest factorial for long double is 1754.00\n";
    
    return 0;
}

