

/* 
 * File:   Question2.cpp
 * Author: Anthony Nunez
 *
 * Created on October 24, 2022, 10:54 PM
 */

#include <cstdlib>
#include <iostream>
#include <string>
#include <cmath>
#include <math.h>
#include <iomanip>
#include <array>

using namespace std;

struct employee{
    float grossPay;
    float payRate;
    float hoursWorked;
    string name;
    string address;
};




int main(int argc, char** argv) {

  employee* worker;
    int workerAmnt;
    cout << "how many workers are you planning on inputting?";
    cin >> workerAmnt;
    
    worker = new employee[workerAmnt];
 
    //for loop that inputs the values for each worker input after having set the array
    for(int i = 0; i < workerAmnt; i++)
        {
        cout << "please enter the name of employee number " << i+1 << endl;
        cin.ignore();
        getline(cin, worker[i].name);
        cout << "enter address of " << worker[i].name << endl;
        cin.ignore();
        getline(cin, worker[i].address);
        
        //error checking for negatives, or numbers too high
        do{
            cout << "how many hours has " << worker[i].name << " worked?" << endl;
            cin >> worker[i].hoursWorked;
            
            if(worker[i].hoursWorked < 0 || worker[i].hoursWorked > 50)
                {
                cout << "invalid input \n";
                }
            }while(worker[i].hoursWorked < 0 || worker[i].hoursWorked > 50);
        do{
            cout << "and what is their hourly rate? \n";
            cin >> worker[i].payRate;
            
            if(worker[i].payRate < 0 || worker[i].payRate > 50)
            {
                cout << "invalid input \n";
            }
            }while(worker[i].payRate < 0 || worker[i].payRate > 50);
            
            
            //do while loop to chip down the hours worked until it gets to 0 
            //and calculate all the different rates for double and triple time
        do
            {
            if(worker[i].hoursWorked > 0 && worker[i].hoursWorked <= 20)
                {
                cout << worker[i].name << " has " << worker[i].hoursWorked * worker[i].payRate << " in straight time \n";
                worker[i].grossPay += worker[i].hoursWorked * worker[i].payRate;
                worker[i].hoursWorked = 0;
                }
            else if(worker[i].hoursWorked > 20 && worker[i].hoursWorked <= 40)
                {
                cout << worker[i].name << " has " << ((worker[i].hoursWorked - 20) * (worker[i].payRate * 2)) << " in double time \n";
                worker[i].grossPay += ((worker[i].hoursWorked - 20) * (worker[i].payRate * 2));
                worker[i].hoursWorked = 20;
                }
            else if(worker[i].hoursWorked > 40)
                {
                cout << worker[i].name << " has " << ((worker[i].hoursWorked - 40) * (worker[i].payRate*3)) << " in triple time \n";
                worker[i].grossPay += ((worker[i].hoursWorked - 40) * (worker[i].payRate * 3));
                worker[i].hoursWorked = 40;
                }
            }while(worker[i].hoursWorked > 0);
            
            // displaying info
            cout << "\nCompany Corp \n";
            cout << worker[i].address << endl;
            cout << "pay addressed to " << worker[i].name << " $" << worker[i].grossPay << endl;
            
            
            //adapted the roman numeral code to convert the final amount into english
            unsigned short englishNumeral = static_cast<unsigned short>(worker[i].grossPay);
            unsigned char n1000s,n100s,n10s,n1s;
            n1000s=englishNumeral/1000;   //Shift 3 places to the left
            n100s=englishNumeral%1000/100;//Remainder of division of 1000 then shift 2 left
            n10s=englishNumeral%100/10;   //Remainder of division of 100 then shift 1 left
            n1s=englishNumeral%10;        //Remainder of division by 10

            //Output the number of 1000's in Roman Numerals
            //Using the Switch Statement
            cout <<(n1000s==4?"four thousand ":
                   n1000s==3?"three thousand ":
                   n1000s==2?"two thousand ":
                   n1000s==1?"one thousand ":"");

           // converting 100s to english with ternary operators
            cout<<(n100s==9?"nine hundred ":
                   n100s==8?"eight hundred ":
                   n100s==7?"seven hundred ":
                   n100s==6?"six hundred ":
                   n100s==5?"five hundred ":
                   n100s==4?"four hundred ":
                   n100s==3?"three hundred ":
                   n100s==2?"two hundred ":
                   n100s==1?"one hundred ":"");

            //converting 10s to english with if statements
            if(n10s==9)cout<<"ninety ";
            if(n10s==8)cout<<"eighty ";
            if(n10s==7)cout<<"seventy ";
            if(n10s==6)cout<<"sixty ";
            if(n10s==5)cout<<"fifty ";
            if(n10s==4)cout<<"forty ";
            if(n10s==3)cout<<"thirty ";
            if(n10s==2)cout<<"twenty ";
            if(n10s==1)cout<<"ten ";

            //converting single digits to english with else if statements
            if(n1s==9)cout<<"nine ";
            else if(n1s==8)cout<<"eight ";
            else if(n1s==7)cout<<"seven ";
            else if(n1s==6)cout<<"six ";
            else if(n1s==5)cout<<"five ";
            else if(n1s==4)cout<<"four ";
            else if(n1s==3)cout<<"three ";
            else if(n1s==2)cout<<"two ";
            else if(n1s==1)cout<<"one ";

            //print the worded amount with cents and the signature line
            float dollars;
            int cents = ((worker[i].grossPay - englishNumeral)*100);
            
            cout << "dollar(s) and " << cents << " cents\n";
            
            cout << "Signature Line: " << endl;
        
        }
        
    
        
    return 0;
}

