/* 
 * File:   main.cpp
 *
 * Author: Anthony Nunez
 *
 * Created on October 21, 2022, 3:17PM
 */
#include <cstdlib>
#include <iostream>
#include <string>
#include <cmath>
#include <math.h>
#include <iomanip>
#include <array>

using namespace std;

// prototypes
void menu();
void number1();
void number2();
void number4();
void number5();
void number6();
void number7();

int main(int argc, char** argv) {
    
    cout << setw(2) << fixed << setprecision(2);
    menu();

    return 0;
}

void menu (){
    
    int problemNumber;
    do{
        cout << "select an integer for which problem you would like to see\n\n";
        cout << "1: output for problem one \n";
        cout << "2: output for problem two \n";
        cout << "3: output for problem three \n";
        cout << "4: output for problem four \n";
        cout << "5: output for problem five \n";
        cout << "6: output for problem six \n";
        cout << "7: output for problem seven \n";
        cin >> problemNumber;
        
        if (problemNumber >7 || problemNumber < 1)
        {
            cout << "incorrect input please enter an integer from 1-7\n";
        }
    }while(problemNumber >7 || problemNumber < 1); // do while loop to check for invalid inputs
    switch(problemNumber){
        
        case 1: number1();
        break;
        
        case 2: number2();
        break;
        
        case 3: cout << "question 3 is included in another project" << endl;
        break;
        
        case 4: number4();
        break;
        
        case 5: number5();
        break;
        
        case 6: number6();
        break;
        
        case 7: number7();
        break;
    }
}
//Struct for question 1
struct customer{
    string accountNumber;
    string name;
    string address;
    float balance;
    float * checks;
    float * deposits;
};

void number1(){
    
    customer person;
    int choiceAmnt = 0;
    int depositAmnt;
    int checkAmnt;
    
    //error check to make sure the length of the bank account number is 5
    do{
        cout << "enter your bank account number \n";
        cin >> person.accountNumber;
        if(person.accountNumber.length() != 5){
            cout << "incorrect input please enter a 5 digit integer \n";
        }
    }while(person.accountNumber.length() != 5);
    
    //input for name, address, and balance
    cout << "enter your name\n";
    cin.ignore();
    getline(cin, person.name);
    cout << "enter your address \n";
    cin.ignore();
    getline(cin, person.address);
    cout << "enter the balance from the beginning of the month\n";
    cin >> person.balance;
    
    //do while loop to check that a valid amount has been input
    do
    {
        cout << "how many checks have you written this month\n";
        cin >> choiceAmnt;
        if(choiceAmnt > 30 || choiceAmnt < 0)
            {
            cout << "incorrect input please enter the amount of checks you have written\n";
            }
    }while (choiceAmnt > 30 || choiceAmnt < 0); //limiting amount of checks to 30
    
    //same do while loop for deposits
    person.checks = new float[choiceAmnt];
    checkAmnt = choiceAmnt;
    
    //for loop to get the amount for checks and get it from balance
    for (int i = 0; i < choiceAmnt; i++) 
        {
        cout << "enter the amount for check number " << i + 1 << endl;
        cin >> person.checks[i];
        person.balance = person.balance - person.checks[i];
        }
    
    //do while loop to get correct amount of deposits
    do{
        cout << "how many deposits to your account has their been \n";
        cin >> choiceAmnt;
        if (choiceAmnt > 30 || choiceAmnt < 0)
        {
            cout << "incorrect input please enter the amount of deposits you have received \n";
        }
    }while(choiceAmnt > 30 || choiceAmnt < 0);
    
    //setting the array 
    person.deposits = new float[choiceAmnt];
    depositAmnt = choiceAmnt;
    
    //for loop to get and add value of deposits to balance
    for (int i = 0; i < choiceAmnt; i++)
        {
        cout << "enter the amount for deposit number " << i + 1 << endl;
        cin >> person.deposits[i];
        person.balance = person.balance + person.deposits[i];
        }
    
    cout << "\nname: " << person.name << "\nAccount Number: " << person.accountNumber << "\nAddress: " << person.address << endl;
    cout << "you have input " << checkAmnt << " checks(s) as well as " << depositAmnt << " deposit(s)" << endl;
    
    //for loop to run through all the values of the checks and deposits
    for (int i = 0; i < checkAmnt; i++)
        {
        cout << "check " << i+1 << ": " << person.checks[i] << endl;
        }
    for (int i = 0; i < depositAmnt; i++)
        {
        cout << "deposit " << i+1 << ": " << person.deposits[i] << endl;
        }
    
    //displaying the rest of the information
    cout << "your new account balance is now " << person.balance << endl;
    if(person.balance < 0)
        {
        cout << "due to having overdrawn you will incur a 35 dollar charge \n";
        person.balance = person.balance - 35.00;
        cout << "your new balance is now " << person.balance;
        }
}

//Struct for question 2 that stores pay, pay rate, hours, and personal details
struct employee{
    float grossPay;
    float payRate;
    float hoursWorked;
    string name;
    string address;
};
void number2(){
    
    employee* worker;
    int workerAmnt;
    cout << "how many workers are you planning on inputting?";
    cin >> workerAmnt;
    
    worker = new employee[workerAmnt];
 
    //for loop that inputs the values for each worker input after having set the array
    for(int i = 0; i < workerAmnt; i++)
        {
        cout << "please enter the name of employee number " << i+1 << endl;
        cin.ignore();
        getline(cin, worker[i].name);
        cout << "enter address of " << worker[i].name << endl;
        cin.ignore();
        getline(cin, worker[i].address);
        
        //error checking for negatives, or numbers too high
        do{
            cout << "how many hours has " << worker[i].name << " worked?" << endl;
            cin >> worker[i].hoursWorked;
            
            if(worker[i].hoursWorked < 0 || worker[i].hoursWorked > 50)
                {
                cout << "invalid input \n";
                }
            }while(worker[i].hoursWorked < 0 || worker[i].hoursWorked > 50);
        do{
            cout << "and what is their hourly rate? \n";
            cin >> worker[i].payRate;
            
            if(worker[i].payRate < 0 || worker[i].payRate > 50)
            {
                cout << "invalid input \n";
            }
            }while(worker[i].payRate < 0 || worker[i].payRate > 50);
            
            
            //do while loop to chip down the hours worked until it gets to 0 
            //and calculate all the different rates for double and triple time
        do
            {
            if(worker[i].hoursWorked > 0 && worker[i].hoursWorked <= 20)
                {
                cout << worker[i].name << " has " << worker[i].hoursWorked * worker[i].payRate << " in straight time \n";
                worker[i].grossPay += worker[i].hoursWorked * worker[i].payRate;
                worker[i].hoursWorked = 0;
                }
            else if(worker[i].hoursWorked > 20 && worker[i].hoursWorked <= 40)
                {
                cout << worker[i].name << " has " << ((worker[i].hoursWorked - 20) * (worker[i].payRate * 2)) << " in double time \n";
                worker[i].grossPay += ((worker[i].hoursWorked - 20) * (worker[i].payRate * 2));
                worker[i].hoursWorked = 20;
                }
            else if(worker[i].hoursWorked > 40)
                {
                cout << worker[i].name << " has " << ((worker[i].hoursWorked - 40) * (worker[i].payRate*3)) << " in triple time \n";
                worker[i].grossPay += ((worker[i].hoursWorked - 40) * (worker[i].payRate * 3));
                worker[i].hoursWorked = 40;
                }
            }while(worker[i].hoursWorked > 0);
            
            // displaying info
            cout << "\nCompany Corp \n";
            cout << worker[i].address << endl;
            cout << "pay addressed to " << worker[i].name << " $" << worker[i].grossPay << endl;
            
            
            //adapted the roman numeral code to convert the final amount into english
            unsigned short englishNumeral = static_cast<unsigned short>(worker[i].grossPay);
            unsigned char n1000s,n100s,n10s,n1s;
            n1000s=englishNumeral/1000;   //Shift 3 places to the left
            n100s=englishNumeral%1000/100;//Remainder of division of 1000 then shift 2 left
            n10s=englishNumeral%100/10;   //Remainder of division of 100 then shift 1 left
            n1s=englishNumeral%10;        //Remainder of division by 10

            //Output the number of 1000's in Roman Numerals
            //Using the Switch Statement
            cout <<(n1000s==4?"four thousand ":
                   n1000s==3?"three thousand ":
                   n1000s==2?"two thousand ":
                   n1000s==1?"one thousand ":"");

           // converting 100s to english with ternary operators
            cout<<(n100s==9?"nine hundred ":
                   n100s==8?"eight hundred ":
                   n100s==7?"seven hundred ":
                   n100s==6?"six hundred ":
                   n100s==5?"five hundred ":
                   n100s==4?"four hundred ":
                   n100s==3?"three hundred ":
                   n100s==2?"two hundred ":
                   n100s==1?"one hundred ":"");

            //converting 10s to english with if statements
            if(n10s==9)cout<<"ninety ";
            if(n10s==8)cout<<"eighty ";
            if(n10s==7)cout<<"seventy ";
            if(n10s==6)cout<<"sixty ";
            if(n10s==5)cout<<"fifty ";
            if(n10s==4)cout<<"forty ";
            if(n10s==3)cout<<"thirty ";
            if(n10s==2)cout<<"twenty ";
            if(n10s==1)cout<<"ten ";

            //converting single digits to english with else if statements
            if(n1s==9)cout<<"nine ";
            else if(n1s==8)cout<<"eight ";
            else if(n1s==7)cout<<"seven ";
            else if(n1s==6)cout<<"six ";
            else if(n1s==5)cout<<"five ";
            else if(n1s==4)cout<<"four ";
            else if(n1s==3)cout<<"three ";
            else if(n1s==2)cout<<"two ";
            else if(n1s==1)cout<<"one ";

            //print the worded amount with cents and the signature line
            float dollars;
            int cents = ((worker[i].grossPay - englishNumeral)*100);
            
            cout << "dollar(s) and " << cents << " cents\n";
            
            cout << "Signature Line: " << endl;
        
        }
        
    
}

void number4(){
    
    int EncryptDecrypt = 0;
    string  code;
    
    //checks for input for whether to encrypt or decrypt 
    do
        {
        cout << "are you encrypting or decrypting a code\n"
                "1:encrypting  \n"
                "2:decrypting  \n"
                "input 1 or 2\n";
        cin >> EncryptDecrypt;
        
        if(EncryptDecrypt > 2 || EncryptDecrypt < 1)
        {
            cout << "incorrect input please enter 1 or 2\n";
        }
        }while(EncryptDecrypt > 2 || EncryptDecrypt < 1);
        
        //switch function between the two
    switch(EncryptDecrypt)
    {
        
        case 1:
        {

            do 
            {
                cout << "enter the 4 digit code\n";
                cin >> code;
                
                //code to check that input is 4 digits long and doesn't have an 8 or 9
                if (code.find_first_of("89") != std::string::npos)
                {
                    cout << "code can't use 8 or 9 please input again\n";
                }
                if(code.length() != 4)
                {
                    cout << "code needs an input of 4 digits or else i get slapped\n";
                }
            }while(code.length() != 4 || code.find_first_of("89") != std::string::npos );
            
            //converts string to an int and then establish an int array
            int integer = stoi(code);
            int charArray[4];
            
            //fill in the int array 
            for(int i=0;i < 4; i++)
                {
                  charArray[3 - i] = integer % 10; 
                  integer /= 10;
                }
            
            //encryption in a for loop that swaps 1,3 2,4 after
            for(int i = 0; i < 4; i++)
                {
                charArray[i] += 6;
                charArray[i] %= 8;
                }
            swap(charArray[0],charArray[2]);
            swap(charArray[1],charArray[3]);
            
            cout << "your new encrypted code is now" << endl;
            for(int i=0;i < 4; i++)
                {
                cout << charArray[i];
                }
            

            break;    
        }
            
        case 2:
        {
            
            
            do 
            {  
                cout << "enter the 4 digit code\n";
                cin >> code;
                
                //same check for input as the encryption 
                if (code.find_first_of("89") != std::string::npos)
                {
                    cout << "code can't use 8 or 9 please input again\n";
                }

                if(code.length() != 4)
                {
                    cout << "code needs an input of 4 digits or else i get slapped\n";
                }
            }while(code.length() != 4 || code.find_first_of("89") != std::string::npos);
            
            int codeEncrypted = stoi(code);
            int charArray[4];
            
            //refill out the information
            for(int i=0;i < 4; i++)
                {
                  charArray[3 - i] = codeEncrypted % 10; 
                  codeEncrypted /= 10;
                }
            
            //decrypt the information
            swap(charArray[0],charArray[2]);
            swap(charArray[1],charArray[3]);
            
            for(int i = 0; i < 4; i++)
                {
                charArray[i] = (charArray[i] +2)%8;
                }
            
            cout << "your decrypted code is going to be \n";
            for(int i=0;i < 4; i++)
                {
                cout << charArray[i];
                }

            
            
            
                break;   
        }
    
    }         
}

void number5(){
    
    
    cout << "largest factorial for char is 1\n";
    cout << "largest factorial for unsigned char is 1\n";
    cout << "largest factorial for short is 7\n";
    cout << "largest factorial for unsigned short is 17\n";
    cout << "largest factorial for int is 16\n";
    cout << "largest factorial for unsigned int is 33\n";
    cout << "largest factorial for long is 20\n";
    cout << "largest factorial for unsigned long is 65\n";
    cout << "largest factorial for long long is 20\n";
    cout << "largest factorial for unsigned long long is 65 \n";
    cout << "largest factorial for float is 34.00\n";
    cout << "largest factorial for double is 170.00\n";
    cout << "largest factorial for long double is 1754.00\n";
    
}

void number6(){
    
    cout << "didn't finish this one" << endl;
}

struct Prime{
    unsigned short prime;
    unsigned char power;
};
struct Primes{
unsigned char nPrimes;
Prime * prime;
};
void number7(){
    
    int n = 0;
    //input for prime number
    do{
    cout << "enter a number between 2 and 65000 that you would like to get the prime factors for\n";
    cin >> n;
    }while(n < 2 || n > 65000);
    
    //math to find the prime factors of the number
    while (n%2 == 0)
        {
          cout<<"2\t";
          n = n/2;
        }
   for (int i = 3; i <= sqrt(n); i = i+2)
    {
       while (n%i == 0)
       {
          cout<<i<<"\t";
          n = n/i;
       }
    }
   if (n > 2)
   cout<<n<<"\t";
}
    
