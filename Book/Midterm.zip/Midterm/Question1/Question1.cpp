
/* 
 * File:   Question1.cpp
 * Author: Anthony Nunez
 *
 * Created on October 24, 2022, 10:51 PM
 */

#include <cstdlib>
#include <iostream>
#include <string>
#include <cmath>
#include <math.h>
#include <iomanip>
#include <array>
using namespace std;

/*
 * 
 */
struct customer{
    string accountNumber;
    string name;
    string address;
    float balance;
    float * checks;
    float * deposits;
};
int main(int argc, char** argv) {

    customer person;
    int choiceAmnt = 0;
    int depositAmnt;
    int checkAmnt;
    
    //error check to make sure the length of the bank account number is 5
    do{
        cout << "enter your bank account number \n";
        cin >> person.accountNumber;
        if(person.accountNumber.length() != 5){
            cout << "incorrect input please enter a 5 digit integer \n";
        }
    }while(person.accountNumber.length() != 5);
    
    //input for name, address, and balance
    cout << "enter your name\n";
    cin.ignore();
    getline(cin, person.name);
    cout << "enter your address \n";
    cin.ignore();
    getline(cin, person.address);
    cout << "enter the balance from the beginning of the month\n";
    cin >> person.balance;
    
    //do while loop to check that a valid amount has been input
    do
    {
        cout << "how many checks have you written this month\n";
        cin >> choiceAmnt;
        if(choiceAmnt > 30 || choiceAmnt < 0)
            {
            cout << "incorrect input please enter the amount of checks you have written\n";
            }
    }while (choiceAmnt > 30 || choiceAmnt < 0); //limiting amount of checks to 30
    
    //same do while loop for deposits
    person.checks = new float[choiceAmnt];
    checkAmnt = choiceAmnt;
    
    //for loop to get the amount for checks and get it from balance
    for (int i = 0; i < choiceAmnt; i++) 
        {
        cout << "enter the amount for check number " << i + 1 << endl;
        cin >> person.checks[i];
        person.balance = person.balance - person.checks[i];
        }
    
    //do while loop to get correct amount of deposits
    do{
        cout << "how many deposits to your account has their been \n";
        cin >> choiceAmnt;
        if (choiceAmnt > 30 || choiceAmnt < 0)
        {
            cout << "incorrect input please enter the amount of deposits you have received \n";
        }
    }while(choiceAmnt > 30 || choiceAmnt < 0);
    
    //setting the array 
    person.deposits = new float[choiceAmnt];
    depositAmnt = choiceAmnt;
    
    //for loop to get and add value of deposits to balance
    for (int i = 0; i < choiceAmnt; i++)
        {
        cout << "enter the amount for deposit number " << i + 1 << endl;
        cin >> person.deposits[i];
        person.balance = person.balance + person.deposits[i];
        }
    
    cout << "\nname: " << person.name << "\nAccount Number: " << person.accountNumber << "\nAddress: " << person.address << endl;
    cout << "you have input " << checkAmnt << " checks(s) as well as " << depositAmnt << " deposit(s)" << endl;
    
    //for loop to run through all the values of the checks and deposits
    for (int i = 0; i < checkAmnt; i++)
        {
        cout << "check " << i+1 << ": " << person.checks[i] << endl;
        }
    for (int i = 0; i < depositAmnt; i++)
        {
        cout << "deposit " << i+1 << ": " << person.deposits[i] << endl;
        }
    
    //displaying the rest of the information
    cout << "your new account balance is now " << person.balance << endl;
    if(person.balance < 0)
        {
        cout << "due to having overdrawn you will incur a 35 dollar charge \n";
        person.balance = person.balance - 35.00;
        cout << "your new balance is now " << person.balance;
        }
    
    return 0;
}

