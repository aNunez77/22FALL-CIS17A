

/* 
 * File:   Question4.cpp
 * Author: Anthony
 *
 * Created on October 24, 2022, 10:59 PM
 */

#include <cstdlib>
#include <iostream>
#include <string>
#include <cmath>
#include <math.h>
#include <iomanip>
#include <array>
using namespace std;


int main(int argc, char** argv) {

    int EncryptDecrypt = 0;
    string  code;
    
    //checks for input for whether to encrypt or decrypt 
    do
        {
        cout << "are you encrypting or decrypting a code\n"
                "1:encrypting  \n"
                "2:decrypting  \n"
                "input 1 or 2\n";
        cin >> EncryptDecrypt;
        
        if(EncryptDecrypt > 2 || EncryptDecrypt < 1)
        {
            cout << "incorrect input please enter 1 or 2\n";
        }
        }while(EncryptDecrypt > 2 || EncryptDecrypt < 1);
        
        //switch function between the two
    switch(EncryptDecrypt)
    {
        
        case 1:
        {

            do 
            {
                cout << "enter the 4 digit code\n";
                cin >> code;
                
                //code to check that input is 4 digits long and doesn't have an 8 or 9
                if (code.find_first_of("89") != std::string::npos)
                {
                    cout << "code can't use 8 or 9 please input again\n";
                }
                if(code.length() != 4)
                {
                    cout << "code needs an input of 4 digits or else i get slapped\n";
                }
            }while(code.length() != 4 || code.find_first_of("89") != std::string::npos );
            
            //converts string to an int and then establish an int array
            int integer = stoi(code);
            int charArray[4];
            
            //fill in the int array 
            for(int i=0;i < 4; i++)
                {
                  charArray[3 - i] = integer % 10; 
                  integer /= 10;
                }
            
            //encryption in a for loop that swaps 1,3 2,4 after
            for(int i = 0; i < 4; i++)
                {
                charArray[i] += 6;
                charArray[i] %= 8;
                }
            swap(charArray[0],charArray[2]);
            swap(charArray[1],charArray[3]);
            
            cout << "your new encrypted code is now" << endl;
            for(int i=0;i < 4; i++)
                {
                cout << charArray[i];
                }
            

            break;    
        }
            
        case 2:
        {
            
            
            do 
            {  
                cout << "enter the 4 digit code\n";
                cin >> code;
                
                //same check for input as the encryption 
                if (code.find_first_of("89") != std::string::npos)
                {
                    cout << "code can't use 8 or 9 please input again\n";
                }

                if(code.length() != 4)
                {
                    cout << "code needs an input of 4 digits or else i get slapped\n";
                }
            }while(code.length() != 4 || code.find_first_of("89") != std::string::npos);
            
            int codeEncrypted = stoi(code);
            int charArray[4];
            
            //refill out the information
            for(int i=0;i < 4; i++)
                {
                  charArray[3 - i] = codeEncrypted % 10; 
                  codeEncrypted /= 10;
                }
            
            //decrypt the information
            swap(charArray[0],charArray[2]);
            swap(charArray[1],charArray[3]);
            
            for(int i = 0; i < 4; i++)
                {
                charArray[i] = (charArray[i] +2)%8;
                }
            
            cout << "your decrypted code is going to be \n";
            for(int i=0;i < 4; i++)
                {
                cout << charArray[i];
                }

            
            
            
                break;   
        }
    
    }         
    return 0;
}

