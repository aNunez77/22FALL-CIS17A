

/* 
 * File:   Question7.cpp
 * Author: Anthony Nunez
 *
 * Created on October 24, 2022, 11:03 PM
 */

#include <cstdlib>
#include <iostream>
#include <string>
#include <cmath>
#include <math.h>
#include <iomanip>
#include <array>
using namespace std;

struct Prime{
    unsigned short prime;
    unsigned char power;
};

struct Primes{
unsigned char nPrimes;
Prime * prime;
};

int main(int argc, char** argv) {

    int n = 0;
    //input for prime number
    do{
    cout << "enter a number between 2 and 65000 that you would like to get the prime factors for\n";
    cin >> n;
    }while(n < 2 || n > 65000);
    
    //math to find the prime factors of the number
    while (n%2 == 0)
        {
          cout<<"2\t";
          n = n/2;
        }
   for (int i = 3; i <= sqrt(n); i = i+2)
    {
       while (n%i == 0)
       {
          cout<<i<<"\t";
          n = n/i;
       }
    }
   if (n > 2)
   cout<<n<<"\t";
    
    return 0;
}

